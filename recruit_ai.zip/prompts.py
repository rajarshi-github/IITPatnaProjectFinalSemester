
def generate_summary_prompt(jd, resume, score):
    return f"""
You are an expert AI Hiring Assistant.

Analyze the candidate based on the job description and resume.

Job Description:
{jd}

Candidate Resume:
{resume}

Match Score: {score}/100

Provide:
1. Top 3 strengths
2. Missing skills (if any)
3. Final hiring recommendation (Interview / Consider / Reject)
4. Short professional summary (3 lines)
"""
