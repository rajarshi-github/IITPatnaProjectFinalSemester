
from tools import parse_resume, extract_skills, match_jd, compute_score
from prompts import generate_summary_prompt
from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def run_recruitment_agent(jd_text: str, resume_text: str):
    """Main Agent Pipeline"""

    # Step 1: Parse Resume
    parsed_resume = parse_resume(resume_text)

    # Step 2: Extract Skills
    skills = extract_skills(parsed_resume)

    # Step 3: Match with JD
    match_details = match_jd(jd_text, skills)

    # Step 4: Compute Score
    score = compute_score(match_details)

    # Step 5: LLM Reasoning Summary
    prompt = generate_summary_prompt(jd_text, resume_text, score)

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        summary = response.choices[0].message.content
    except Exception:
        summary = "LLM summary unavailable. (Check API key or internet connection)"

    # Step 6: Agent Decision Logic
    if score >= 75:
        decision = "Interview"
    elif score >= 50:
        decision = "Consider"
    else:
        decision = "Reject"

    return {
        "score": score,
        "summary": summary,
        "decision": decision,
        "skills": skills,
        "match_details": match_details
    }
