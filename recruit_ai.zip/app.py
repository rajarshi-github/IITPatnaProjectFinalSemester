
import streamlit as st
from agent import run_recruitment_agent
from utils import extract_text_from_pdf

st.set_page_config(page_title="Recruit-AI", layout="wide")

st.title("🤖 Recruit-AI: Agentic Hiring Assistant")
st.markdown("### AI-powered Resume Screening & Interview Recommendation")

st.sidebar.header("Upload Files")

jd_file = st.sidebar.file_uploader("Upload Job Description (txt/pdf)", type=["txt", "pdf"])
resume_file = st.sidebar.file_uploader("Upload Resume (txt/pdf)", type=["txt", "pdf"])

jd_text = ""
resume_text = ""

if jd_file:
    if jd_file.type == "application/pdf":
        jd_text = extract_text_from_pdf(jd_file)
    else:
        jd_text = jd_file.read().decode("utf-8")

if resume_file:
    if resume_file.type == "application/pdf":
        resume_text = extract_text_from_pdf(resume_file)
    else:
        resume_text = resume_file.read().decode("utf-8")

st.subheader("Or Paste Text Manually")
jd_text_manual = st.text_area("📄 Job Description", value=jd_text, height=200)
resume_text_manual = st.text_area("📑 Resume Text", value=resume_text, height=200)

if st.button("🔍 Analyze Candidate"):
    if jd_text_manual and resume_text_manual:
        with st.spinner("Running Agentic AI Analysis..."):
            result = run_recruitment_agent(jd_text_manual, resume_text_manual)

        col1, col2, col3 = st.columns(3)

        col1.metric("📊 Match Score", f"{result['score']}/100")
        col2.metric("🧠 Decision", result["decision"])
        col3.metric("🛠 Skills Found", len(result["skills"]))

        st.subheader("🧠 AI Evaluation Summary")
        st.write(result["summary"])

        st.subheader("🛠 Extracted Skills")
        st.write(result["skills"])

        st.subheader("📌 Skill Match Breakdown")
        st.json(result["match_details"])

    else:
        st.warning("Please upload or paste both Job Description and Resume.")
