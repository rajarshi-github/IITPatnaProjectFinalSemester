
import re

def parse_resume(resume_text: str) -> str:
    """Basic preprocessing of resume text"""
    return resume_text.lower()


def extract_skills(parsed_resume: str):
    """Extract skills using keyword matching"""
    skill_keywords = [
        "python", "machine learning", "deep learning",
        "nlp", "sql", "tensorflow", "pytorch", "llm",
        "data analysis", "aws", "docker", "react", "java"
    ]
    found_skills = [skill for skill in skill_keywords if skill in parsed_resume]
    return list(set(found_skills))


def match_jd(jd_text: str, skills: list):
    """Match extracted skills with job description"""
    jd_text = jd_text.lower()
    match_details = {skill: (skill in jd_text) for skill in skills}
    return match_details


def compute_score(match_details: dict) -> int:
    """Compute matching score"""
    if not match_details:
        return 0
    score = (sum(match_details.values()) / len(match_details)) * 100
    return int(score)
